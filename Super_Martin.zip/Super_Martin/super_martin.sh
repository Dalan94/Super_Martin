#!/bin/bash
cd Super_Martin
./super_martin
