#!/bin/bash
cd Level_Editor
./super_martin_level_editor
